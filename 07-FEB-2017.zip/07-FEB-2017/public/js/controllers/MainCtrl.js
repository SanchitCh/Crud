sampleApp.controller('MainController', function($scope) {

	$scope.tagline = 'Welcome to movie booking website!';	

});